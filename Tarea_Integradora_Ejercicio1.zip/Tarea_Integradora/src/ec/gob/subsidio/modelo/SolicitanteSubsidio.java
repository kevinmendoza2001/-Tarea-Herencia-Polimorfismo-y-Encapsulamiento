package ec.gob.subsidio.modelo;

public class SolicitanteSubsidio {
    private String nombreCompleto;
    private String cedula;
    private double ingresosMensuales;
    private int cantidadVehiculos;
    private boolean viveEnEcuador;

    public SolicitanteSubsidio(String nombreCompleto,String cedula,double ingresosMensuales, int cantidadVehiculos,boolean viveEnEcuador){
        this.nombreCompleto = nombreCompleto;
        this.cedula = cedula;
        this.ingresosMensuales = ingresosMensuales;
        this.cantidadVehiculos = cantidadVehiculos;
        this.viveEnEcuador = viveEnEcuador;
    }

    public String getNombreCompleto(){
        return nombreCompleto;
    }
    public String getCedula(){
        return cedula;
    }
    public double getIngresosMensuales(){
        return ingresosMensuales;
    }

    public void setIngresosMensuales(double ingresosMensuales){
        if(ingresosMensuales >= 470){
            this.ingresosMensuales = ingresosMensuales;
        }else{
            System.out.println("Ingreso no valido");
        }
    }

    public void setCantidadVehiculos(int cantidadVehiculos){
        if(cantidadVehiculos >= 0){
            this.cantidadVehiculos = cantidadVehiculos;
        }else{
            System.out.println("Cantidad de vehiculos no validos");
        }
    }

    public boolean isViveEnEcuador(){
        return viveEnEcuador;
    }

    public void setViveEnEcuador(boolean viveEnEcuador) {
        this.viveEnEcuador = viveEnEcuador;
    }

    //Metodos para el subsidio
    public boolean subsidioAprobado(){
        return ingresosMensuales <= 1200 &&
                cantidadVehiculos <= 1 && viveEnEcuador;
    }

    public void generarResultado(){
        if (subsidioAprobado()){
            System.out.println("Subsidio Aprobado");
        }else{
            System.out.println("Subsidio rechazado");
        } if (ingresosMensuales > 1200){
            System.out.println(" - Ingreso mayores a 1200");
        } if (cantidadVehiculos > 1){
            System.out.println(" - Mas de un vehiculo");
        } if (!viveEnEcuador) {
            System.out.println("No vive en Ecuador");
        }
    }

    //Metodos para consumo
    public double calcularConsumoMensual(){
        double km = 1000;
        return km/40;
    }

    public double calcularConsumoMensual(double kmExtra){
        double km = 1000 + kmExtra;
        return km / 40;
    }

    //Metodo Estatico
    public static void mostrarSubsidio(){
        System.out.println("----- Reglas de subsidio -----");
        System.out.println(" - Ingresos mayor o igual a 1200");
        System.out.println(" - Maximo 1 vehiculo");
        System.out.println(" - Vivir en Ecuador");
    }

    @Override
    public String toString(){
        return "\nDATOS DEL SOLICITANTE" + "\nNombre completo: " + nombreCompleto +
                "\nCedula: " + cedula + "\nIngresos: " + ingresosMensuales +
                "\nVehiculos: " + cantidadVehiculos + "\nVive en Ecuador: " + viveEnEcuador;
    }
}
