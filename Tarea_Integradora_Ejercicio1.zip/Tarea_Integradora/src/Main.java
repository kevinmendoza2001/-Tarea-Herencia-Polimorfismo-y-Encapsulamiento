import java.util.Scanner;
import ec.gob.subsidio.modelo.SolicitanteSubsidio;
void main() {
    Scanner sc = new Scanner(System.in);

    //Metodo mostrar reglas
    SolicitanteSubsidio.mostrarSubsidio();
    //Pedir datos
    System.out.println("Ingrese nombre completo: ");
    String nombre = sc.nextLine();
    System.out.println("Ingrese número de cedula: ");
    String cedula = sc.nextLine();
    System.out.println("Ingrese ingresos mensuales: ");
    double ingresos = sc.nextDouble();
    System.out.println("Ingrese la cantidad de vehiculos: ");
    int vehiculos = sc.nextInt();
    System.out.println("¿Vive en Ecuador? (true/false): ");
    boolean vive = sc.nextBoolean();

    //Creacion de objetos
    SolicitanteSubsidio s = new SolicitanteSubsidio(nombre,cedula,ingresos,vehiculos,vive);
    //Aplicacion de validaciones con setter
    s.setIngresosMensuales(ingresos);
    s.setCantidadVehiculos(vehiculos);
    s.setViveEnEcuador(vive);

    //Mostrar datos ingresados
    System.out.println(s);
    //Generacion de los resultados
    System.out.println("---- RESULTADO DE LA APROBACION ----");
    s.generarResultado();
    //Consumo
    System.out.println("Consumo mensual: " + s.calcularConsumoMensual() + " Galones");
    System.out.println("Consumo con km extra: " + s.calcularConsumoMensual(100) + " Galones");

}
