public class CuentaCorriente extends CuentaBancaria {

    // Aquí declaramos "static" para que sea fija las cantidades de sobregiros
    private static final double SOBREGIRO_MAXIMO = 500;

    public CuentaCorriente(String numeroCuenta, String titular, double saldoInicial) {
        super(numeroCuenta, titular, saldoInicial);
    }

    @Override
    public void retirar(double monto) {
        if (monto <= 0) {
            throw new IllegalArgumentException("No se permiten retiros negativos o cero.");
        }

        // Permite sobregiro hasta -500
        if (getSaldo() - monto < -SOBREGIRO_MAXIMO) {
            throw new IllegalArgumentException("Sobregiro excedido. Máximo permitido: 500 USD.");
        }

        setSaldo(getSaldo() - monto);
    }

    @Override
    public double calcularInteresMensual() {
        // no genera interés
        return 0;
    }
}
