public class CuentaAhorros extends CuentaBancaria {

    // Aquí declaramos "static" para que sea fija la tasa anual, es decir
    // todas las cuentas contarán con el mismo valor
    private static final double TASA_ANUAL = 0.03;

    // Creamos el siguiente constructor heredando de la clase padre y
    // usamos "super" para indicar que vamos a trabajar con lo que está
    // adentro de esta clase
    public CuentaAhorros(String numeroCuenta, String titular, double saldoInicial) {
        super(numeroCuenta, titular, saldoInicial);
    }

    @Override
    public double calcularInteresMensual() {
        return getSaldo() * (TASA_ANUAL / 12);
    }
}
