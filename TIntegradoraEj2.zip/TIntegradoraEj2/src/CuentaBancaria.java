public abstract class CuentaBancaria {

    // Aplicamos encapsulamiento con atributos privados
    private String numeroCuenta;
    private String titular;
    private double saldo;

    // Creamos un constructor e inicializamos
    public CuentaBancaria(String numeroCuenta, String titular, double saldoInicial) {
        this.numeroCuenta = numeroCuenta;
        this.titular = titular;
        // Validamos para no permitir saldos iniciales negativos
        if (saldoInicial < 0) {
            // Utilizando esta palabra reservada podemos asegurarnos que no vamos a tener
            // problemas al momento de imprimir, es una instancia que protege el código
            // haciendo que este tenga sentido
            throw new IllegalArgumentException("El saldo inicial no puede ser negativo.");
        }
        this.saldo = saldoInicial;
    }

    // Getters (solo lectura)
    public String getNumeroCuenta() {
        return numeroCuenta;
    }
    public String getTitular() {
        return titular;
    }
    public double getSaldo() {
        return saldo;
    }

    // Con este metodo procuramos que no se pueda manipular el saldo
    protected void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    // Usamos este metodo para validar los depositos
    public void depositar(double monto) {
        if (monto <= 0) {
            throw new IllegalArgumentException("No se permiten depósitos negativos o cero.");
        }
        saldo += monto;
    }

    // Metodo para retirar dinero
    public void retirar(double monto) {
        if (monto <= 0) {
            throw new IllegalArgumentException("No se permiten retiros negativos o cero.");
        }
        if (monto > saldo) {
            throw new IllegalArgumentException("Sin fondos suficientes.");
        }
        saldo -= monto;
    }

    // Metodo abstracto
    public abstract double calcularInteresMensual();

    // Metodo para aplicar interés y reusarlo
    public void aplicarInteres() {
        double interes = calcularInteresMensual();
        saldo += interes;
    }
}
