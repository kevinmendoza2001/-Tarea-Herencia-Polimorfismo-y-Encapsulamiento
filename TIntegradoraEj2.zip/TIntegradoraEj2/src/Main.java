// Importamos las palabras reservadas para utizar en el codigo arreglos y listas
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        // Creamos la lista
        List<CuentaBancaria> cuentas = new ArrayList<>();

        // El ".add" es un metodo de las listas, su función es insertar un
        // objeto dentro de una lista
        cuentas.add(new CuentaAhorros("AH001", "Ana Pérez", 1200));
        cuentas.add(new CuentaCorriente("CC001", "Luis Gómez", 800));
        cuentas.add(new CuentaInversion("INV001", "María López", 7000));

        double totalInteresesBanco = 0;

        System.out.println("===== REPORTE MENSUAL DEL BANCO =====");

        for (CuentaBancaria cuenta : cuentas) {

            double interesMensual = cuenta.calcularInteresMensual();
            totalInteresesBanco += interesMensual;

            // Con esto actualizamos el interes
            cuenta.aplicarInteres();
            // "%.2f USD" palabra reservada para imprimir en formato de dinero
            System.out.println("Número de Cuenta: " + cuenta.getNumeroCuenta());
            System.out.println("Titular: " + cuenta.getTitular());
            System.out.printf("Interés Mensual Generado: %.2f USD\n", interesMensual);
            System.out.printf("Saldo Actualizado: %.2f USD\n", cuenta.getSaldo());
            System.out.println("-----------------------------------");
        }

        System.out.printf("\nTOTAL INTERESES GENERADOS POR EL BANCO: %.2f USD\n", totalInteresesBanco);
    }
}
